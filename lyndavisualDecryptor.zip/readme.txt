Lynda Visual Decryptor - Version 1.0 r11
============================
Designed and Developed By :
Mohammad Ibrahim
medos20.mi@gmail.com
============================
This free Software offer Visual Interface for the Command Line (Lynda Decryptor) So you Can Decrypt Lynda Desktop Downloaded Offline Courses Instead of Using Command Line, the software is based on Tobias Becht (Lynda Decryotor) but replacing the boring and Hard to use Black CMD Interface with Visual and Easy to Use GUI for the final User, not all the functions in the Original Version are Converted to the GUI but the main function and the ability to covert complete video course are of-course supported in the GUI, this program assumed that you have legal Lynda/Linked-in Account into your computer , this software are not to pirate lynda videos its just for your personal use to save you a lot of time in case you need to watch the video courses anytime even after formatting your system, now you can keep your decrypted video files safe in other place (DON�T DISTRIBUTE THE VIDEO COURSES!) .

IMPORTANT! :
You MUST Install (Lynda Desktop APP) from Lynda.com (Only Version that Support Windows 7+) are Supported in the Lynda Visual Decryptor and that can be downloaded from :
https://www.lynda.com/apps/desktop-app

The Program Can Run Directly (no need to Setup anything) just extract the (Lyndavisualdecryptor.zip) and then Run the Program (lvdok.exe) and it will make a shortcut in the Desktop with the name of (Lynda Visual Decrytor).


Thanks and Credits to :
Tobias Becht : The Original Developer of (Lynda Decryptor) Command Line Version
https://github.com/h4ck-rOOt
Dmytro Sokhach : The Developer who Modified Tobias Prog to Support Video2Brain (LDCW) Side by Side with the (LYNDA) format.
https://github.com/DmytroSokhach
Matei Domnita : The Developer that Add the ability to convert .captions to .srt
https://github.com/mdomnita
Valentin Schmidt : C++ and Multimedia Developer Very interested in Developing Scripting Xtras for Adobe / Macromedia Director � he is the One who Created Shell Xtra Responsible to Run Command Line Software Inside Director Environment
http://www.dasdeck.com/
Gary Smith : The Owner and Developer of Buddy API Xtra � API Xtra for  Director to Control Windows
http://www.mods.com.au/


All Right Reserved to Mohammad Ibrahim � The Developer of Lynda Visual Decryptor
https://github.com/medos20
Thanks to Allah (GOD) for all the Help

----------------------------
--END OF README--
----------------------------




